import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CnegoService {

  constructor(public httpClient: HttpClient) { }

  
  getCneg(){
    return new Promise(resolve => {
      var headers = new Headers();
      this.httpClient.get('https://unidesarrollo.com.mx/api/cnego').subscribe(data => {
        resolve(data);
      }, err => {
        console.log(err);
      });
    });
  }

  getEdos(){
    return new Promise(resolve => {
      var headers = new Headers();
      this.httpClient.get('https://unidesarrollo.com.mx/api/edos?id=190').subscribe(data => {
        resolve(data);
      }, err => {
        console.log(err);
      });
    });
  }


  getCreateUser(data){
    const options = {
      headers: {
       'Content-Type': 'application/json'
     }
   };
    return new Promise(resolve => {
      this.httpClient.post('https://localhost/unides/public/api/apireguser',data, options).subscribe(datos => {
        resolve(datos);
      }, err => {
        console.log(err);
      });
    });
  }

  getAuthUser(data){

    const options = {
      headers: {
       'Content-Type': 'application/json'
     }
    };
  return new Promise(resolve => {
      this.httpClient.post('https://localhost/unides/public/api/loguser',data, options).subscribe(datos => {
        resolve(datos);
      }, err => {
        console.log(err);
      });
    });
  }

  getNego(){
    return new Promise(resolve => {
      this.httpClient.get('https://jsonplaceholder.typicode.com/todos/1').subscribe(data => {
        resolve(data);
      }, err => {
        console.log(err);
      });
    });
  }

  /*saveRegister(dataToSend){
    var url = "";
  }*/



}
