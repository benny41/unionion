import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registertest',
  templateUrl: './registertest.page.html',
  styleUrls: ['./registertest.page.scss'],
})
export class RegistertestPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
